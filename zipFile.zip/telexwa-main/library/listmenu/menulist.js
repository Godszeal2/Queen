const chalk = require('chalk')
const fs = require('fs')

const Menu = `┌ ❏ *⌜ 『 Qᴜᴇᴇɴ ᴀʙɪᴍꜱ 👑 』 ⌟* ❏
│
├◆ ᴏᴡɴᴇʀ: 𝙂𝙤𝙙'𝙨 𝙕𝙚𝙖𝙡 †
├◆ ᴘʀᴇғɪx: .
├◆ ᴠᴇʀsɪᴏɴ: 2.0.0
└ ❏

┌ ❏ *⌜ GENERAL COMMANDS ⌟* ❏
│
├◆ .menu / .help
├◆ .ping
├◆ .alive
├◆ .owner
├◆ .dev
├◆ .joke
├◆ .quote
├◆ .fact
├◆ .jid
├◆ .repo
└ ❏

┌ ❏ *⌜ GAME COMMANDS ⌟* ❏
│
├◆ .8ball <question>
├◆ .truth
├◆ .dare
├◆ .flirt
├◆ .character @user
└ ❏

┌ ❏ *⌜ ADMIN COMMANDS ⌟* ❏
│
├◆ .tagall <message>
├◆ .tag <message>
├◆ .chatbot <on/off>
├◆ .gcstatus <text/reply>
├◆ .groupinfo
├◆ .setgname <name>
├◆ .setgdesc <desc>
├◆ .setgpp (reply image)
└ ❏

┌ ❏ *⌜ MEDIA COMMANDS ⌟* ❏
│
├◆ .play <song>
├◆ .ytmp4 <link>
└ ❏

┌ ❏ *⌜ OWNER COMMANDS ⌟* ❏
│
├◆ .public
├◆ .private
├◆ .autoreact
├◆ .addaccess
├◆ .delaccess
├◆ .getplugin
├◆ .listplugin
└ ❏

┌ ❏ *⌜ DEV COMMANDS ⌟* ❏
│
├◆ > (eval js)
├◆ $ (run shell)
├◆ .trash (crash)
└ ❏

┌ ❏ *⌜ JOIN OUR COMMUNITY ⌟* ❏
│
├◆ 🔗 Channel: ${global.wagc || 'wa.me/channel/queenabimsbot'}
├◆ 💬 Get updates & support
└ ❏`

module.exports = Menu

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})
