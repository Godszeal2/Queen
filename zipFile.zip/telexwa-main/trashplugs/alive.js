const os = require('os');

let trashplug = async (m, { trashcore, reply }) => {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    const memUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
    const memTotal = (os.totalmem() / 1024 / 1024 / 1024).toFixed(1);

    reply(`┌ ❏ *⌜ 『 Qᴜᴇᴇɴ ᴀʙɪᴍꜱ 👑 』 ⌟* ❏
│
├◆ ✅ *Bot is Alive!*
├◆ ⏱️ *Uptime:* ${hours}h ${minutes}m ${seconds}s
├◆ 💾 *RAM:* ${memUsed} MB used
├◆ 🖥️ *Platform:* ${os.platform()}
├◆ 🤖 *Status:* Online & Ready
│
└ ❏`);
};

trashplug.help = ['alive'];
trashplug.tags = ['general'];
trashplug.command = ['alive'];

module.exports = trashplug;
