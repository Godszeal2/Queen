const axios = require('axios');

let trashplug = async (m, { reply }) => {
    try {
        const response = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');
        const fact = response.data.text;
        reply(`💡 *Random Fact*\n\n${fact}`);
    } catch (error) {
        reply('❌ Could not fetch a fact right now. Try again later.');
    }
};

trashplug.help = ['fact'];
trashplug.tags = ['general'];
trashplug.command = ['fact'];

module.exports = trashplug;
