const axios = require('axios');

let trashplug = async (m, { reply }) => {
    try {
        const res = await axios.get('https://api.dreaded.site/api/flirt');
        const flirtMessage = res.data?.result || res.data?.message || res.data;
        if (!flirtMessage || typeof flirtMessage !== 'string') throw new Error('No result');
        reply(`💕 *Flirt*\n\n${flirtMessage}`);
    } catch (error) {
        const lines = [
            "You must be a magician because every time I look at you, everyone else disappears. 😍",
            "Do you have a map? I keep getting lost in your eyes. 😏",
            "Is your name Google? Because you have everything I've been searching for. 💫",
            "Are you a camera? Because every time I see you, I smile. 😊",
            "If you were a vegetable, you'd be a cute-cumber. 🥒"
        ];
        reply(`💕 *Flirt*\n\n${lines[Math.floor(Math.random() * lines.length)]}`);
    }
};

trashplug.help = ['flirt'];
trashplug.tags = ['fun'];
trashplug.command = ['flirt'];

module.exports = trashplug;
