const fs = require('fs');
const path = require('path');
const axios = require('axios');

const DATA_FILE = path.join(__dirname, '../data/chatbotData.json');

function loadData() {
    try {
        return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch {
        return {};
    }
}

function saveData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error('Chatbot data save error:', e.message);
    }
}

let trashplug = async (m, { trashcore, reply, text, command }) => {
    const from = m.chat;
    const sender = m.key.participant || m.key.remoteJid;
    const botNumber = trashcore.user.id.split(':')[0] + '@s.whatsapp.net';

    if (command === 'chatbot') {
        const arg = text.toLowerCase().trim();

        const isOwner = sender.includes(trashcore.user.id.split(':')[0]);
        let isSenderAdmin = isOwner;

        if (!isOwner && from.endsWith('@g.us')) {
            try {
                const meta = await trashcore.groupMetadata(from);
                isSenderAdmin = meta.participants.some(p => p.id === sender && (p.admin === 'admin' || p.admin === 'superadmin'));
            } catch {}
        }

        if (!isSenderAdmin) return reply('❌ Only admins or owner can use this command.');

        const data = loadData();

        if (arg === 'on') {
            data[from] = true;
            saveData(data);
            return reply('✅ Chatbot *enabled* for this group!\n\nMention or reply to me to chat.');
        } else if (arg === 'off') {
            delete data[from];
            saveData(data);
            return reply('✅ Chatbot *disabled* for this group.');
        } else {
            return reply('ℹ️ Usage:\n• `.chatbot on` — Enable chatbot\n• `.chatbot off` — Disable chatbot');
        }
    }

    // This handles incoming messages when chatbot is active
    const data = loadData();
    if (!data[from]) return;

    const isMentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.includes(botNumber);
    const isReplyToBot = m.message?.extendedTextMessage?.contextInfo?.participant === botNumber;

    if (!isMentioned && !isReplyToBot) return;

    const userMsg = (m.message?.conversation || m.message?.extendedTextMessage?.text || '')
        .replace(new RegExp(`@${botNumber.split('@')[0]}`, 'g'), '')
        .trim();

    if (!userMsg) return;

    try {
        await trashcore.sendPresenceUpdate('composing', from);
        await new Promise(r => setTimeout(r, 2000));

        const res = await axios.get(`https://api.dreaded.site/api/chatgpt?text=${encodeURIComponent(userMsg)}`);
        const answer = res.data?.result?.prompt || res.data?.result;

        if (answer && typeof answer === 'string') {
            await trashcore.sendMessage(from, { text: answer.trim() }, { quoted: m });
        } else {
            await trashcore.sendMessage(from, { text: "Hmm, let me think about that... 🤔 Try again!" }, { quoted: m });
        }
    } catch (e) {
        await trashcore.sendMessage(from, { text: "Oops! 😅 Something went wrong. Try again later." }, { quoted: m });
    }
};

trashplug.help = ['chatbot <on/off>'];
trashplug.tags = ['admin'];
trashplug.command = ['chatbot'];

module.exports = trashplug;
